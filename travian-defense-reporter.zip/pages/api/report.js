import { PrismaClient } from "@prisma/client";
const prisma = new PrismaClient();

export default async function handler(req, res) {
  if (req.method === "POST") {
    const { defenderCoords, attackerCoords, landingTime, firstSeenTime, tribe, reporter } = req.body;

    const report = await prisma.attackReport.create({
      data: {
        defenderCoords,
        attackerCoords,
        landingTime: new Date(landingTime),
        firstSeenTime: new Date(firstSeenTime),
        tribe,
        reporter
      }
    });

    return res.status(200).json({ success: true, report });
  } else {
    return res.status(405).end();
  }
}