import { useState } from "react";

export default function Home() {
  const [result, setResult] = useState(null);

  function calculateDistance(x1, y1, x2, y2) {
    const mapSize = 200;
    const dx = Math.abs(x1 - x2);
    const dy = Math.abs(y1 - y2);
    const wrappedDx = Math.min(dx, mapSize - dx);
    const wrappedDy = Math.min(dy, mapSize - dy);
    return Math.sqrt(wrappedDx ** 2 + wrappedDy ** 2);
  }

  function calculateTravelTimes(distance, tribe) {
    const speeds = {
      Teuton: { Scout: 9, Infantry: 6, Ram: 4, Catapult: 3 },
      Roman: { Scout: 16, Infantry: 6, Ram: 4, Catapult: 3 },
      Gaul: { Scout: 17, Infantry: 6, Ram: 5, Catapult: 4 }
    };

    const unitSpeeds = speeds[tribe];
    const times = {};
    for (const unit in unitSpeeds) {
      const hours = distance / unitSpeeds[unit];
      const h = Math.floor(hours);
      const m = Math.round((hours - h) * 60);
      times[unit] = `${h}:${m.toString().padStart(2, '0')}`;
    }
    return times;
  }

  async function handleSubmit(e) {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.target).entries());
    const [x1, y1] = data.defenderCoords.split('|').map(Number);
    const [x2, y2] = data.attackerCoords.split('|').map(Number);
    const distance = calculateDistance(x1, y1, x2, y2);
    const travelTimes = calculateTravelTimes(distance, data.tribe);
    setResult({ distance: distance.toFixed(2), travelTimes });

    await fetch("/api/report", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
  }

  return (
    <main className="p-8 max-w-xl mx-auto">
      <h1 className="text-2xl font-bold mb-6">Travian Defense Reporter</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <input name="defenderCoords" required placeholder="Defender coords (e.g. 123|456)" className="border w-full p-2" />
        <input name="attackerCoords" required placeholder="Attacker coords (e.g. 234|567)" className="border w-full p-2" />
        <input name="landingTime" type="datetime-local" required className="border w-full p-2" />
        <input name="firstSeenTime" type="datetime-local" required className="border w-full p-2" />
        <select name="tribe" required className="border w-full p-2">
          <option value="">Select Tribe</option>
          <option value="Teuton">Teuton</option>
          <option value="Roman">Roman</option>
          <option value="Gaul">Gaul</option>
        </select>
        <input name="reporter" placeholder="Your name (optional)" className="border w-full p-2" />
        <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded">Submit Report</button>
      </form>

      {result && (
        <div className="mt-6 p-4 border rounded">
          <p><strong>Distance:</strong> {result.distance} fields</p>
          <h2 className="font-semibold mt-2">Travel Times:</h2>
          <ul>
            {Object.entries(result.travelTimes).map(([unit, time]) => (
              <li key={unit}>{unit}: {time}</li>
            ))}
          </ul>
        </div>
      )}
    </main>
  );
}